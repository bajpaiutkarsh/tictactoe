const electron = require('electron')
const {app, BrowserWindow} = electron
app.on('ready', () =>{
    var mainWindow = new BrowserWindow({
        width :1280,
        height : 720,
        icon : 'logo.ico',
         title: "My App"
    })
    mainWindow.setMenu(null);
    mainWindow.loadURL('file://'+__dirname+'/app/index.html');
});