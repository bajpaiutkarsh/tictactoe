class check
{
static int tic[];
public static void main(String args[])
{
tic=new int[2];
tic t1=new tic();
tic=t1.main();
System.out.println(tic[0]+"\n"+tic[1]);
}
}
