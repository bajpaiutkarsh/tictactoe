//background image
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

import javax.swing.SwingUtilities;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import javax.swing.border.LineBorder;


public class JBackGroundImageDemo extends JFrame implements ActionListener
{
static int temp[]=new int[2];
static int arr[]=new int[9];
static int tic[][];
static int chance=0;
		static int player[],system[],count;
static int player_level=0;
static int last1,last2;
 Container con = null;
    JPanel panelBgImg;
	JFrame f1;
static JButton l1,play,ins,exit11,back11;
	int x=1;
	int x11=0;
	static int playing=0;
	String str[]={"welcome.png","bg.jpg","instr.png"};//"welcome1.png"};
    static JButton b11,b12,b13,x1,x2,x3,x4,x5,x6,x7,x8,x9,o1,o2,o3,o4,o5,o6,o7,o8,o9,b1,b2,b3,b4,b5,b6,b7,b8,b9,p1,p2,computer,exit,try_again,undo,back;
    public JBackGroundImageDemo()
    {
		setTitle("Tic Tac Toe~V1.0");
        con = getContentPane();
            con.setLayout(null);
        ImageIcon imh = new ImageIcon(str[x11]);
        setSize(1015, 600);
        panelBgImg = new JPanel()
        {
            public void paintComponent(Graphics g) 
            {
                Image img = new ImageIcon(str[x11]).getImage();
                Dimension size = new Dimension(1015,600);
                setPreferredSize(size);
                setMinimumSize(size);
                setMaximumSize(size);
                setSize(size);
                setLayout(null);
                g.drawImage(img, 0, 0, null);
            } 
        };
        con.add(panelBgImg);
        panelBgImg.setBounds(0, 0, 1015,600);
        GridBagLayout layout = new GridBagLayout();
      JPanel panelContent = new JPanel(layout);
        GridBagConstraints gc = new GridBagConstraints();
  gc.insets = new Insets(3, 3, 3, 3);
        gc.gridx = 1;
        gc.gridy = 1;
		ImageIcon play1 = new ImageIcon("play.png");
		ImageIcon back111 = new ImageIcon("back.png");
		ImageIcon ins1 = new ImageIcon("ins.png");
		ImageIcon exit111 = new ImageIcon("exit2.png");
		ImageIcon invalid = new ImageIcon("invalid.png");
		ImageIcon undo1 = new ImageIcon("undo.png");
		ImageIcon try_again1= new ImageIcon("try again.png");
		ImageIcon back1= new ImageIcon("back.png");
		ImageIcon exit1= new ImageIcon("exit.png");
		ImageIcon pi2 = new ImageIcon("p2.png");
		ImageIcon pi1 = new ImageIcon("p1.png");
        ImageIcon icon1 = new ImageIcon("conti.png");
		ImageIcon icon2 = new ImageIcon("ONE.png");
		ImageIcon icon3 = new ImageIcon("two.png");
		ImageIcon xi1 = new ImageIcon("x1.png");
		ImageIcon xi2 = new ImageIcon("x2.png");
		ImageIcon xi3 = new ImageIcon("x2.png");
		ImageIcon xi4 = new ImageIcon("x4.png");
		ImageIcon xi5 = new ImageIcon("x5.png");
		ImageIcon xi6 = new ImageIcon("x6.png");
		ImageIcon xi7 = new ImageIcon("x7.png");
		ImageIcon xi8 = new ImageIcon("x8.png");
		ImageIcon xi9 = new ImageIcon("x9.png");
		ImageIcon bi1 = new ImageIcon("b1.png");
		ImageIcon bi2 = new ImageIcon("b2.png");
		ImageIcon bi3 = new ImageIcon("b3.png");
		ImageIcon bi4 = new ImageIcon("b4.png");
		ImageIcon bi5 = new ImageIcon("b5.png");
		ImageIcon bi6 = new ImageIcon("b6.png");
		ImageIcon bi7 = new ImageIcon("b7.png");
		ImageIcon bi8 = new ImageIcon("b8.png");
		ImageIcon bi9 = new ImageIcon("b9.png");
		ImageIcon oi1 = new ImageIcon("o1.png");
		ImageIcon oi2 = new ImageIcon("o2.png");
		ImageIcon oi3 = new ImageIcon("o3.png");
		ImageIcon oi4 = new ImageIcon("o4.png");
		ImageIcon oi5 = new ImageIcon("o5.png");
		ImageIcon oi6 = new ImageIcon("o6.png");
		ImageIcon oi7 = new ImageIcon("o7.png");
		ImageIcon oi8 = new ImageIcon("o8.png");
		ImageIcon oi9 = new ImageIcon("o9.png");
		try_again = new JButton("continue",try_again1);
		try_again.addActionListener(this);
		exit = new JButton("continue",exit1);
		exit.addActionListener(this);
        b11 = new JButton("continue",icon1);
		b11.addActionListener(this);
		
		back11 = new JButton("continue",back111);
		back11.addActionListener(this);
		play = new JButton("continue",play1);
		play.addActionListener(this);
		ins= new JButton("continue",ins1);
		ins.addActionListener(this);
		exit11 = new JButton("continue",exit111);
		exit11.addActionListener(this);
		
		b12 = new JButton("One Player",icon2);
		b12.addActionListener(this);
		b13 = new JButton("Two Player",icon3);
		b13.addActionListener(this);
		 x1 = new JButton("continue",xi1);
		 x1.addActionListener(this);
		 x2 = new JButton("continue",xi2);
		 x2.addActionListener(this);
		 x3 = new JButton("continue",xi3);
		 x3.addActionListener(this);
		 x4 = new JButton("continue",xi4);
		 x4.addActionListener(this);
		 x5 = new JButton("continue",xi5);
		 x5.addActionListener(this);
		 x6 = new JButton("continue",xi6);
		 x6.addActionListener(this);
		 x7 = new JButton("continue",xi7);
		 x7.addActionListener(this);
		 x8 = new JButton("continue",xi8);
		 x8.addActionListener(this);
		 x9 = new JButton("continue",xi9);
		 x9.addActionListener(this);
		 b1 = new JButton("continue",bi1);
		 b1.addActionListener(this);
		 b2 = new JButton("continue",bi2);
		 b2.addActionListener(this);
		 b3 = new JButton("continue",bi3);
		 b3.addActionListener(this);
		 b4 = new JButton("continue",bi4);
		 b4.addActionListener(this);
		 b5 = new JButton("continue",bi5);
		 b5.addActionListener(this);
		 b6 = new JButton("continue",bi6);
		 b6.addActionListener(this);
		 b7 = new JButton("continue",bi7);
		 b7.addActionListener(this);
		 b8 = new JButton("continue",bi8);
		 b8.addActionListener(this);
		 b9 = new JButton("continue",bi9);
		 b9.addActionListener(this);
		undo=new JButton("undo",undo1);
		undo.addActionListener(this);
		back=new JButton("back",back1);
		back.addActionListener(this);
		o1 = new JButton("continue",oi1);
		 o1.addActionListener(this);
		 o2 = new JButton("continue",oi2);
		 o2.addActionListener(this);
		 o3 = new JButton("continue",oi3);
		 o3.addActionListener(this);
		 o4 = new JButton("continue",oi4);
		 o4.addActionListener(this);
		 o5 = new JButton("continue",oi5);
		 o5.addActionListener(this);
		 o6 = new JButton("continue",oi6);
		 o6.addActionListener(this);
		 o7 = new JButton("continue",oi7);
		 o7.addActionListener(this);
		 o8 = new JButton("continue",oi8);
		 o8.addActionListener(this);
		 o9 = new JButton("continue",oi9);
		 o9.addActionListener(this);
		 p1 = new JButton("one",pi1);
		 p1.addActionListener(this);
		 p2 = new JButton("continue",pi2);
		 p2.addActionListener(this);
		 l1=new JButton("invalid move...",invalid);
		panelBgImg.setLayout(null);
		panelBgImg.add(b12);
		panelBgImg.add(b13);
		panelBgImg.add(x1);
		panelBgImg.add(x2);
		panelBgImg.add(x3);
		panelBgImg.add(x4);
		panelBgImg.add(x5);
		panelBgImg.add(x6);
		panelBgImg.add(x7);
		panelBgImg.add(x8);
		panelBgImg.add(x9);
		panelBgImg.add(p1);
		panelBgImg.add(p2);
		panelBgImg.add(b1);
		panelBgImg.add(b2);
		panelBgImg.add(b3);
		panelBgImg.add(b4);
		panelBgImg.add(b5);
		panelBgImg.add(b6);
		panelBgImg.add(b7);
		panelBgImg.add(b8);
		panelBgImg.add(b9);
		panelBgImg.add(l1);
		panelBgImg.add(o1);
		panelBgImg.add(o2);
		panelBgImg.add(o3);
		panelBgImg.add(o4);
		panelBgImg.add(o5);
		panelBgImg.add(o6);
		panelBgImg.add(o7);
		panelBgImg.add(o8);
		panelBgImg.add(o9);
		
		panelBgImg.add(play);
		panelBgImg.add(back11);
		panelBgImg.add(ins);
		panelBgImg.add(exit11);
		
		panelBgImg.add(try_again);
		panelBgImg.add(exit);
		panelBgImg.add(back);
		panelBgImg.add(undo);
		b12.setBounds(150,450,155,45);
		
		play.setBounds(150,450,155,45);
		ins.setBounds(450,450,155,45);
		exit11.setBounds(750,450,155,45);
		back11.setBounds(550,450,155,45);
		
		x1.setBounds(180,120,78,83);
		x2.setBounds(350,120,78,83);
		x3.setBounds(500,120,78,83);
		x4.setBounds(180,300,78,83);
		x5.setBounds(350,300,78,83);
		x6.setBounds(500,300,78,83);
		x7.setBounds(180,480,78,83);
		x8.setBounds(350,480,78,83);
		x9.setBounds(500,480,78,83);
		back.setBounds(750,260,142,50);
		try_again.setBounds(750,200,145,50);
		exit.setBounds(750,320,142,50);
		b1.setBounds(180,120,78,83);
		b2.setBounds(350,120,78,83);
		b3.setBounds(500,120,78,83);
		b4.setBounds(180,300,78,83);
		b5.setBounds(350,300,78,83);
		b6.setBounds(500,300,78,83);
		b7.setBounds(180,480,78,83);
		b8.setBounds(350,480,78,83);
		b9.setBounds(500,480,78,83);
		p1.setBounds(25,25,205,58);
		p2.setBounds(25,25,205,58);
		undo.setBounds(750,140,145,50);
		o1.setBounds(180,120,90,83);
		o2.setBounds(350,120,90,83);
		o3.setBounds(500,120,90,83);
		o4.setBounds(180,300,90,83);
		o5.setBounds(350,300,90,83);
		o6.setBounds(500,300,90,83);
		o7.setBounds(180,480,90,83);
		o8.setBounds(350,480,90,83);
		o9.setBounds(500,480,90,83);
		b13.setBounds(350,450,155,45);
		l1.setBounds(300,600,271,30);
		b12.setVisible(false);
		b13.setVisible(false);
		x1.setVisible(false);
		x2.setVisible(false);
		x3.setVisible(false);
		x4.setVisible(false);
		x5.setVisible(false);
		x6.setVisible(false);
		x7.setVisible(false);
		x8.setVisible(false);
		x9.setVisible(false);
		l1.setVisible(false);
				o1.setVisible(false);
		o2.setVisible(false);
		o3.setVisible(false);
		o4.setVisible(false);
		o5.setVisible(false);
		o6.setVisible(false);
		o7.setVisible(false);
		o8.setVisible(false);
		o9.setVisible(false);
		try_again.setVisible(false);
		undo.setVisible(false);
		back.setVisible(false);
		exit.setVisible(false);
        setResizable(false);
		b1.setVisible(false);
		b2.setVisible(false);
		b3.setVisible(false);
		b4.setVisible(false);
		b5.setVisible(false);
		b6.setVisible(false);
		b7.setVisible(false);
		b8.setVisible(false);
		b9.setVisible(false);
		p1.setVisible(false);
		back11.setVisible(false);
		p2.setVisible(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public static void main(String[] args)throws IOException 
    {
		tic=new int[3][3];
			player=new int[2];
			system=new int[2];
		count=0;
			for(int m=0;m<3;m++)
			{
			for(int h=0;h<3;h++)
			{
				tic[m][h]=5;
			}
			}
	    new JBackGroundImageDemo().setVisible(true);
    }
	public void actionPerformed(ActionEvent ae)
	{	
		if(ae.getSource()==ins)
		{
		try
		{
		String shutdownCmd = "instr";
			Process child = Runtime.getRuntime().exec(shutdownCmd);
		}
		catch(Exception e)
		{
		}
		}
		if(ae.getSource()==back11)
		{
		
		play.setVisible(true);
		ins.setVisible(true);
		b12.setVisible(false);
		b13.setVisible(false);
		back11.setVisible(false);
		
		}
		if(ae.getSource()==exit11)
		{
		System.exit(2);
		}
		
		if(ae.getSource()==back)
		{
		count=0;
			for(int m=0;m<3;m++)
			{
			for(int h=0;h<3;h++)
			{
				tic[m][h]=5;
			}
			}
			
			x11=(x11+1)%2;
		       ImageIcon imh = new ImageIcon(str[x11]);
        setSize(imh.getIconWidth(), imh.getIconHeight());
        panelBgImg = new JPanel()
        {
            public void paintComponent(Graphics g) 
            {
                Image img = new ImageIcon(str[x11]).getImage();
                Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));
                setPreferredSize(size);
                setMinimumSize(size);
                setMaximumSize(size);
                setSize(size);
                setLayout(null);
                g.drawImage(img, 0, 0, null);
            } 
        };
        con.add(panelBgImg);
        panelBgImg.setBounds(0, 0, imh.getIconWidth(), imh.getIconHeight());
        GridBagLayout layout = new GridBagLayout();
        JPanel panelContent = new JPanel(layout);
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(3, 3, 3, 3);
        gc.gridx = 1;
        gc.gridy = 1;
		b12.setVisible(true);
		b13.setVisible(true);
		x1.setVisible(false);
		x2.setVisible(false);
		x3.setVisible(false);
		x4.setVisible(false);
		x5.setVisible(false);
		x6.setVisible(false);
		x7.setVisible(false);
		x8.setVisible(false);
		x9.setVisible(false);
		l1.setVisible(false);
				o1.setVisible(false);
		o2.setVisible(false);
		o3.setVisible(false);
		o4.setVisible(false);
		o5.setVisible(false);
		o6.setVisible(false);
		o7.setVisible(false);
		o8.setVisible(false);
		o9.setVisible(false);
		try_again.setVisible(false);
		undo.setVisible(false);
		back.setVisible(false);
		exit.setVisible(false);
		back11.setVisible(true);
		exit11.setVisible(true);
        setResizable(false);
		b1.setVisible(false);
		b2.setVisible(false);
		b3.setVisible(false);
		b4.setVisible(false);
		b5.setVisible(false);
		b6.setVisible(false);
		b7.setVisible(false);
		b8.setVisible(false);
		b9.setVisible(false);
		p1.setVisible(false);
		p2.setVisible(false);
		}
		if(ae.getSource()==b12)
		{
		player_level=1;
		x11=(x11+1)%2;
		       ImageIcon imh = new ImageIcon(str[x11]);
        setSize(imh.getIconWidth(), imh.getIconHeight());
        panelBgImg = new JPanel()
        {
            public void paintComponent(Graphics g) 
            {
                Image img = new ImageIcon(str[x11]).getImage();
                Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));
                setPreferredSize(size);
                setMinimumSize(size);
                setMaximumSize(size);
                setSize(size);
                setLayout(null);
                g.drawImage(img, 0, 0, null);
            } 
        };
        con.add(panelBgImg);
        panelBgImg.setBounds(0, 0, imh.getIconWidth(), imh.getIconHeight());
        GridBagLayout layout = new GridBagLayout();
        JPanel panelContent = new JPanel(layout);
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(3, 3, 3, 3);
        gc.gridx = 1;
        gc.gridy = 1;
		b12.setVisible(false);
		b13.setVisible(false);
		p1.setVisible(true);
		try_again.setVisible(true);
		undo.setVisible(true);
		back.setVisible(true);
		exit.setVisible(true);
			b1.setVisible(true);
		b2.setVisible(true);
		b3.setVisible(true);
		b4.setVisible(true);
		b5.setVisible(true);
		b6.setVisible(true);
		b7.setVisible(true);
		b8.setVisible(true);
		b9.setVisible(true);
		l1.setVisible(false);
		back11.setVisible(false);
		exit11.setVisible(false);
			}
		
		if(ae.getSource()==b13)
		{
		back11.setVisible(false);
		exit11.setVisible(false);
		player_level=2;
		x11=(x11+1)%2;
		       ImageIcon imh = new ImageIcon(str[x11]);
        setSize(imh.getIconWidth(), imh.getIconHeight());
        
        panelBgImg = new JPanel()
        {
            public void paintComponent(Graphics g) 
            {
                Image img = new ImageIcon(str[x11]).getImage();
                Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));
                setPreferredSize(size);
                setMinimumSize(size);
                setMaximumSize(size);
                setSize(size);
                setLayout(null);
                g.drawImage(img, 0, 0, null);
            } 
        };
        
        con.add(panelBgImg);
        panelBgImg.setBounds(0, 0, imh.getIconWidth(), imh.getIconHeight());
        
        GridBagLayout layout = new GridBagLayout();
        
        JPanel panelContent = new JPanel(layout);
        GridBagConstraints gc = new GridBagConstraints();

        gc.insets = new Insets(3, 3, 3, 3);
        gc.gridx = 1;
        gc.gridy = 1;
		b12.setVisible(false);
	b13.setVisible(false);
		b1.setVisible(true);
		b2.setVisible(true);
		b3.setVisible(true);
		b4.setVisible(true);
		b5.setVisible(true);
		b6.setVisible(true);
		b7.setVisible(true);
		b8.setVisible(true);
		b9.setVisible(true);
		l1.setVisible(false);
		try_again.setVisible(true);
		undo.setVisible(true);
		back.setVisible(true);
		exit.setVisible(true);
		if(playing==0)
		{
		p1.setVisible(true);
		p2.setVisible(false);
		
		}
		else
		{
		p2.setVisible(true);
		p1.setVisible(false);
	
		}
		}
		if(ae.getSource()==play)
		{
		back11.setVisible(true);
		b12.setVisible(true);
		b13.setVisible(true);
		play.setVisible(false);
		ins.setVisible(false);
		}
		
		if(ae.getSource()==undo)
		{
		if(player_level==2)
		{
		undo(last1,last2);
		}
		else if(player_level==1)
		{
		undo(system[0],system[1]);
		undo(last1,last2);
		}
		}
		if(ae.getSource()==b1)
		{  
		
		if(player_level==2)
		{
l1.setVisible(false);			if(playing==0)
				{
					x1.setVisible(true);
					b1.setVisible(false);
					game(1,0,0);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
					
					
				}
				else
				{
					o1.setVisible(true);
					b1.setVisible(false);
					game(2,0,0);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
		else if(player_level==1)                         
		{                        
		//code for player1
		x1.setVisible(true);
b1.setVisible(false);
		temp=sysgame(0,0);
		on(temp[0],temp[1],1);
		checkkd1();
		}
		}
			if(ae.getSource()==b2)
		{  
		if(player_level==2)
		{
		l1.setVisible(false);
		if(playing==0)
				{
					x2.setVisible(true);
					b2.setVisible(false);
					game(1,0,1);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o2.setVisible(true);
					b2.setVisible(false);
					game(2,0,1);
					playing=0;
if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
					}
				
		}
		else if(player_level==1)                          
		{                         
		//code for player1
		x2.setVisible(true);
					b2.setVisible(false);
		temp=sysgame(0,1);
		on(temp[0],temp[1],1);
		checkkd1();
		}
		}
			if(ae.getSource()==b3)
		{ 
		if(player_level==2)
		{
		l1.setVisible(false);
			if(playing==0)
				{
					x3.setVisible(true);
					b3.setVisible(false);
                    game(1,0,2);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o3.setVisible(true);
					b3.setVisible(false);
					game(2,0,2);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
		else if(player_level==1)                        
		{         
		//code for player1
		x3.setVisible(true);
					b3.setVisible(false);
		temp=sysgame(0,2);
		on(temp[0],temp[1],1);
		checkkd1();
		}
		}
			if(ae.getSource()==b4)
		{
		if(player_level==2)
		{
		l1.setVisible(false);
			if(playing==0)
				{
					x4.setVisible(true);
					b4.setVisible(false);
					game(1,1,0);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o4.setVisible(true);
					b4.setVisible(false);
					game(2,1,0);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
		else if(player_level==1)                        
		{
		//code for player1
		x4.setVisible(true);
					b4.setVisible(false);
		temp=sysgame(1,0);
		
		on(temp[0],temp[1],1);
		checkkd1();
		}
		
	}
			if(ae.getSource()==b5)
		{  
		if(player_level==2)
		{
		l1.setVisible(false);
			if(playing==0)
				{
					x5.setVisible(true);
					b5.setVisible(false);
					game(1,1,1);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o5.setVisible(true);
					b5.setVisible(false);
					game(2,1,1);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
		else if(player_level==1)                     
		{          
		//code for player1
		x5.setVisible(true);
					b5.setVisible(false);
		temp=sysgame(1,1);
		on(temp[0],temp[1],1);
		checkkd1();
}
		}
			if(ae.getSource()==b6)
		{  
		if(player_level==2)
		{
		l1.setVisible(false);
			if(playing==0)
				{
					x6.setVisible(true);
					b6.setVisible(false);
					game(1,1,2);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o6.setVisible(true);
					b6.setVisible(false);
					game(2,1,2);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
		else if(player_level==1)                      
		{        
		//code for player1
		x6.setVisible(true);
					b6.setVisible(false);
		temp=sysgame(1,2);
		
		on(temp[0],temp[1],1);
		checkkd1();

		}
		}
		
		
			if(ae.getSource()==b7)
		{
		if(player_level==2)
		{
		l1.setVisible(false);
			if(playing==0)
				{
					x7.setVisible(true);
					b7.setVisible(false);
					game(1,2,0);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o7.setVisible(true);
					b7.setVisible(false);
					game(2,2,0);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
		else if(player_level==1)                     
		{          
		//code for player1
		x7.setVisible(true);
					b7.setVisible(false);
		temp=sysgame(2,0);
		
		on(temp[0],temp[1],1);
		checkkd1();

		}
		}
		if(ae.getSource()==b8)
		{
		if(player_level==2)
		{
		l1.setVisible(false);
			if(playing==0)
				{
					x8.setVisible(true);
					b8.setVisible(false);
					game(1,2,1);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o8.setVisible(true);
					b8.setVisible(false);
					game(2,2,1);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
		else if(player_level==1)
		{
		//code for player 1
		x8.setVisible(true);
					b8.setVisible(false);
		temp=sysgame(2,1);
		
		on(temp[0],temp[1],1);
		checkkd1();
}
}
		if(ae.getSource()==b9)
		{  
		if(player_level==2)
		{
		l1.setVisible(false);
			if(playing==0)
				{
					x9.setVisible(true);
					b9.setVisible(false);
					game(1,2,2);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o9.setVisible(true);
					b9.setVisible(false);
					game(2,2,2);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
		else if(player_level==1)
		{
		//code for player 1
		x9.setVisible(true);
					b9.setVisible(false);
		temp=sysgame(2,2);
		on(temp[0],temp[1],1);
		checkkd1();

		}
		}
		if(ae.getSource()==o1)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o2)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o3)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o4)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o5)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o6)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o7)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o8)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o9)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x1)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x2)
	{
	l1.setVisible(true);
	}
	
	if(ae.getSource()==x3)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x4)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x5)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x6)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x7)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x8)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x9)
	{
	l1.setVisible(true);
	}
		if(ae.getSource()==exit)
	{
	System.exit(1);
	}
		if(ae.getSource()==try_again)
	{
	
		count=0;
	for(int m=0;m<3;m++)
			{
			for(int h=0;h<3;h++)
			{
				tic[m][h]=5;
			}
			}
	player[0]=player[1]=-5;
		playing=0;
		p1.setVisible(true);
		undo.setVisible(true);
		p2.setVisible(false);
		x1.setVisible(false);
		x2.setVisible(false);
		x3.setVisible(false);
		x4.setVisible(false);
		x5.setVisible(false);
		x6.setVisible(false);
		x7.setVisible(false);
		x8.setVisible(false);
		x9.setVisible(false);
		o1.setVisible(false);
		o2.setVisible(false);
		o3.setVisible(false);
		o4.setVisible(false);
		o5.setVisible(false);
		o6.setVisible(false);
		o7.setVisible(false);
		o8.setVisible(false);
		o9.setVisible(false);
		b1.setVisible(true);
		b2.setVisible(true);
		b3.setVisible(true);
		b4.setVisible(true);
		b5.setVisible(true);
		b6.setVisible(true);
		b7.setVisible(true);
		b8.setVisible(true);
		b9.setVisible(true);

	}
	}
	
	static void undo(int x,int y)
	{
	playing=chance;
	if(playing==0)
	{
	p1.setVisible(true);
	p2.setVisible(false);
	}
	else if(playing==1)
	{
	p2.setVisible(true);
	p1.setVisible(false);
	}
	tic[x][y]=5;
     if(x==0 && y==0)
{
x1.setVisible(false);
o1.setVisible(false);
b1.setVisible(true);
}
else if(x==0 && y==1)
{
x2.setVisible(false);
o2.setVisible(false);
b2.setVisible(true);
}
else if(x==0 && y==2)
{
x3.setVisible(false);
o3.setVisible(false);
b3.setVisible(true);
}
else if(x==1 && y==0)
{
x4.setVisible(false);
o4.setVisible(false);
b4.setVisible(true);
}
else if(x==1 && y==1)
{
x5.setVisible(false);
o5.setVisible(false);
b5.setVisible(true);
}
else if(x==1 && y==2)
{
x6.setVisible(false);
o6.setVisible(false);
b6.setVisible(true);
}

else if(x==2 && y==0)
{
x7.setVisible(false);
o7.setVisible(false);
b7.setVisible(true);
}
else if(x==2 && y==1)
{
x8.setVisible(false);
o8.setVisible(false);
b8.setVisible(true);
}
else if(x==2 && y==2)
{
x9.setVisible(false);
o9.setVisible(false);
b9.setVisible(true);
}	
	}
	
	
static void game(int value,int place1,int place2)
{
last1=place1;
last2=place2;
chance=value-1;
tic[place1][place2]=value;

if(((tic[0][0]==1)&&(tic[0][1]==1)&&(tic[0][2]==1))||((tic[1][0]==1)&&(tic[1][1]==1)&&(tic[1][2]==1))||((tic[2][0]==1)&&(tic[2][1]==1)&&(tic[2][2]==1))||((tic[0][0]==1)&&(tic[1][0]==1)&&(tic[2][0]==1))||((tic[0][1]==1)&&(tic[1][1]==1)&&(tic[2][1]==1))||((tic[0][2]==1)&&(tic[1][2]==1)&&(tic[2][2]==1))||((tic[0][0]==1)&&(tic[1][1]==1)&&(tic[2][2]==1))||((tic[2][0]==1)&&(tic[1][1]==1)&&(tic[0][2]==1)))
{
try
{

String shutdownCmd = "player1won";
			Process child = Runtime.getRuntime().exec(shutdownCmd);
		exit.setVisible(true);
		try_again.setVisible(true);
		undo.setVisible(false);
		b1.setVisible(false);
		b2.setVisible(false);
		b3.setVisible(false);
		b4.setVisible(false);
		b5.setVisible(false);
		b6.setVisible(false);
		b7.setVisible(false);
		b8.setVisible(false);
		b9.setVisible(false);

		}
		catch(Exception e)
		{
		}
		}
		
		else if(((tic[0][0]==2)&&(tic[0][1]==2)&&(tic[0][2]==2))||((tic[1][0]==2)&&(tic[1][1]==2)&&(tic[1][2]==2))||((tic[2][0]==2)&&(tic[2][1]==2)&&(tic[2][2]==2))||((tic[0][0]==2)&&(tic[1][0]==2)&&(tic[2][0]==2))||((tic[0][1]==2)&&(tic[1][1]==2)&&(tic[2][1]==2))||((tic[0][2]==2)&&(tic[1][2]==2)&&(tic[2][2]==2))||((tic[0][0]==2)&&(tic[1][1]==2)&&(tic[2][2]==2))||((tic[2][0]==2)&&(tic[1][1]==2)&&(tic[0][2]==2)))
{
try
{
b1.setVisible(false);
		b2.setVisible(false);
		b3.setVisible(false);
		b4.setVisible(false);
		b5.setVisible(false);
		b6.setVisible(false);
		b7.setVisible(false);
		b8.setVisible(false);
		b9.setVisible(false);
		undo.setVisible(false);
String shutdownCmd = "player2won";
			Process child = Runtime.getRuntime().exec(shutdownCmd);
		exit.setVisible(true);
		try_again.setVisible(true);
		}
		catch(Exception e)
		{
		}
		}
		else
		{
		 checkkd1();
		}
}
//////////////////////////////////
static void checkkd1()
{
int ch=0;
for(int i=0;i<3;i++)
{
for(int j=0;j<3;j++)
{
if(tic[i][j]==5)
{
ch=5;
break;
}
}
}
if(ch!=5)
{
try
{
for(int m=0;m<3;m++)
			{
			for(int h=0;h<3;h++)
			{
				tic[m][h]=5;
			}
			}
String shutdownCmd = "kd";
			Process child = Runtime.getRuntime().exec(shutdownCmd);
		exit.setVisible(true);
		try_again.setVisible(true);
		b1.setVisible(false);
		b2.setVisible(false);
		undo.setVisible(false);
		b3.setVisible(false);
		b4.setVisible(false);
		b5.setVisible(false);
		b6.setVisible(false);
		b7.setVisible(false);
		b8.setVisible(false);
		b9.setVisible(false);
		}
		catch(Exception e)
		{

}
		}
}
/*code for auto-system place generator.... be caution*/

public static int[] sysgame(int x_pos,int y_pos)
		{	
			last1=x_pos;
			last2=y_pos;
		//display();
				if(count == 9)
				{
					try
{
for(int m=0;m<3;m++)
			{
			for(int h=0;h<3;h++)
			{
				tic[m][h]=5;
			}
			}
String shutdownCmd = "kd";
			Process child = Runtime.getRuntime().exec(shutdownCmd);
		exit.setVisible(true);
		try_again.setVisible(true);
		b1.setVisible(false);
		b2.setVisible(false);
		b3.setVisible(false);
		b4.setVisible(false);
		b5.setVisible(false);
		b6.setVisible(false);
		b7.setVisible(false);
		b8.setVisible(false);
		b9.setVisible(false);
		undo.setVisible(false);
		}
		catch(Exception e)
		{

}
			}	
				else
				{
				askmove(x_pos,y_pos);
				if(isvalid()==0)
				{
					System.out.printf("\n\n@@ !!! Invalid move !!! @@\n\n");
				//	askmove();
				}
			//	display();
				if(win()==1)
				{
					try
					{
					for(int m=0;m<3;m++)
			{
			for(int h=0;h<3;h++)
			{
				tic[m][h]=5;
			}
			}
					String shutdownCmd = "player1won";
			Process child = Runtime.getRuntime().exec(shutdownCmd);
		exit.setVisible(true);
		try_again.setVisible(true);
b1.setVisible(false);
undo.setVisible(false);
		b2.setVisible(false);
		b3.setVisible(false);
		b4.setVisible(false);
		b5.setVisible(false);
		b6.setVisible(false);
		b7.setVisible(false);
		b8.setVisible(false);
		b9.setVisible(false);	
	}
		catch(Exception e)
		{
		}
					//break;
				}
				int m = findmove();
				
				if(m!=0)
				{	
					sysmove();
				//	display();
					if(m==5)
					{
						try
					{
					for(int m1=0;m1<3;m1++)
			{
			for(int h=0;h<3;h++)
			{
				tic[m1][h]=5;
			}
			}
					String shutdownCmd = "loose";
			Process child = Runtime.getRuntime().exec(shutdownCmd);
			b1.setVisible(false);
		b2.setVisible(false);
		undo.setVisible(false);
		b3.setVisible(false);
		b4.setVisible(false);
		b5.setVisible(false);
		b6.setVisible(false);
		b7.setVisible(false);
		b8.setVisible(false);
		b9.setVisible(false);
	exit.setVisible(true);
		try_again.setVisible(true);
		}
		catch(Exception e)
		{
		}
						//	break;
					}
					
				}
				}
			
		return system;
		}
		static void askmove(int a,int b)
		{	
			
			player[0]=a;
			player[1]=b;
		}
		static void sysmove()
		{
			System.out.printf("The system position for '0' is : ");
			System.out.printf(" %d %d ",system[0],system[1]);
		}
		static int isvalid()
		{
			if((player[0]>=0&&player[0]<=2)&&(player[1]>=0&&player[1]<=2)&&(tic[player[0]][player[1]] == 5))
			{
				tic[player[0]][player[1]] = 1 ;
				count++;
				return 1;
			}
			else
				return 0 ;
		}
		static int findmove()
{	int i,j,c=0,d=0,f=0,e=0,g=0;
				if(trywin(system[0],system[1]))
				{
					system[0]=player[0];
					system[1]=player[1];
					tic[system[0]][system[1]]=0;
					
					return 5;
					
				}
				
	
				if(checkwin(player[0],player[1]))
				{
					system[0]=player[0];
					system[1]=player[1];
					tic[system[0]][system[1]]=0;
					count++;
					return 1;
					
				}
				if(tic[1][1]==5)
				{
				system[0]=1;
					system[1]=1;
					tic[system[0]][system[1]]=0;
					count++;
					return 1;
				
				}
if((tic[1][1]==1))
{	
	if(tic[0][0]==5)
	{


					system[0]=0;
					system[1]=0;
					tic[system[0]][system[1]]=0;
					count++;
					return 1;}
	else if(tic[2][0]==5)
	{


					system[0]=2;
					system[1]=0;
					tic[system[0]][system[1]]=0;
					count++;
					return 1;}
	else if(tic[0][2]==5)
{


					system[0]=0;
					system[1]=2;
					tic[system[0]][system[1]]=0;
					count++;
					return 1;}	
else if(tic[2][2]==5)
{


					system[0]=2;
					system[1]=2;
					tic[system[0]][system[1]]=0;
					count++;
					return 1;}	


}	
			
				
		
	int cn =0;
	for(i=player[0]-1;i<=player[0]+1;i++)
	{
		for(j=player[1]-1;j<=player[1]+1;j++)
		{
			if((i>=0&&i<=2)&&(j>=0&&j<=2)&&(tic[i][j] == 5))
			{	
				if(player[0]==2&&player[1]==2)
				{
					f=2;
				}
				else
				{
					f=1;
				}
				if(cn==0)
				{cn++;
					c = i;
				d = j;	
				}
				
				if((i==0&&j==0)||(i==0&&j==2)||(i==2&&j==0)||(i==2&&j==2))
				{
					system[0]=i;
				system[1]=j;
				tic[i][j]=0;
				count++;
				return 1 ;
				}
				e=i;
				g=j;
			}
			
		}
	}
	if(f==1)
	{
	system[0]=c;
				system[1]=d;
				tic[c][d]=0;
				count++;
				return 1 ;
	}			
	else if(f==2)
	{system[0]=e;
				system[1]=g;
				tic[e][g]=0;
				count++;
				return 1 ;
	
	}
	for(i=0;i<=2;i++)
	{
		for(j=0;j<=2;j++)
		{
			if(tic[i][j]==5)
			{
				tic[i][j]=0;
				system[0]=i;
				system[1]=j;
				return 1;
			}
		}
	}
	return 0 ;
}
		static boolean checkwin(int a,int b)
		{	

		boolean f =false;	
				if((tic[a][0]==1)&&(tic[a][1]==1)&&(tic[a][2]==5))
				{	f=true;
					player[0]=a;
					player[1]=2;
				}
				else if((tic[a][0]==1)&&(tic[a][1]==5)&&(tic[a][2]==1))
				{	f=true;
					player[0]=a;
					player[1]=1;
				}
				else if((tic[a][0]==5)&&(tic[a][1]==1)&&(tic[a][2]==1))
				{	f=true;
					player[0]=a;
					player[1]=0;
				}
				else if((tic[0][b]==1)&&(tic[1][b]==1)&&(tic[2][b]==5))
				{	player[0]=2;
					player[1]=b;
					f=true;
				}
				else if((tic[0][b]==1)&&(tic[1][b]==5)&&(tic[2][b]==1))
				{	player[0]=1;
					player[1]=b;
					f=true;
				}
				else if((tic[0][b]==5)&&(tic[1][b]==1)&&(tic[2][b]==1))
				{	player[0]=0;
					player[1]=b;
					f=true;
				}
				else if((a==0&&b==0)||(b==2&&a==2)||(a==1&&b==1))
				{
						if((tic[0][0]==1)&&(tic[1][1]==1)&&(tic[2][2]==5))
						{f=true;
							player[0]=2;
							player[1]=2;
						}
						else if((tic[0][0]==1)&&(tic[2][2]==1)&&(tic[1][1]==5))
						{f=true;
							player[0]=1;
							player[1]=1;
						}
						else if((tic[2][2]==1)&&(tic[1][1]==1)&&(tic[0][0]==5))
						{f=true;
							player[0]=0;
							player[1]=0;
							
						}
				}
				else if((b==0&&a==2)||(a==0&&b==2)||(a==1&&b==1))
				{
						if((tic[0][2]==1)&&(tic[1][1]==1)&&(tic[2][0]==5))
						{f=true;
						player[0]=2;
							player[1]=0;
						}
						else if((tic[0][2]==1)&&(tic[2][0]==1)&&(tic[1][1]==5))
						{ f=true;
							player[0]=1;
							player[1]=1;
						}
						else if((tic[2][0]==1)&&(tic[1][1]==1)&&(tic[0][2]==5))
						{f=true;
							player[0]=0;
							player[1]=2;
						}
						
				}
				
					
					return f;
		}
		static boolean trywin(int a,int b)
		{	

		boolean f =false;	
				if((tic[a][0]==0)&&(tic[a][1]==0)&&(tic[a][2]==5))
				{	f=true;
					player[0]=a;
					player[1]=2;
				}
				else if((tic[a][0]==0)&&(tic[a][2]==0)&&(tic[a][1]==5))
				{	f=true;
					player[0]=a;
					player[1]=1;
				}
				else if((tic[a][2]==0)&&(tic[a][1]==0)&&(tic[a][0]==5))
				{	f=true;
					player[0]=a;
					player[1]=0;
				}
				else if((tic[0][b]==0)&&(tic[1][b]==0)&&(tic[2][b]==5))
				{	player[0]=2;
					player[1]=b;
					f=true;
				}
				else if((tic[0][b]==0)&&(tic[2][b]==0)&&(tic[1][b]==5))
				{	player[0]=1;
					player[1]=b;
					f=true;
				}
				else if((tic[2][b]==0)&&(tic[1][b]==0)&&(tic[0][b]==5))
				{	player[0]=0;
					player[1]=b;
					f=true;
				}
				else if((a==0&&b==0)||(b==2&&a==2)||(a==1&&b==1))
				{
						if((tic[0][0]==0)&&(tic[1][1]==0)&&(tic[2][2]==5))
						{f=true;
							player[0]=2;
							player[1]=2;
						}
						else if((tic[0][0]==0)&&(tic[2][2]==0)&&(tic[1][1]==5))
						{f=true;
							player[0]=1;
							player[1]=1;
						}
						else if((tic[2][2]==0)&&(tic[1][1]==0)&&(tic[0][0]==5))
						{f=true;
							player[0]=0;
							player[1]=0;
							
						}
				}
				else if((b==0&&a==2)||(a==0&&b==2)||(a==1&&b==1))
				{
						if((tic[0][2]==0)&&(tic[1][1]==0)&&(tic[2][0]==5))
						{f=true;
						player[0]=2;
							player[1]=0;
						}
						else if((tic[0][2]==0)&&(tic[2][0]==0)&&(tic[1][1]==5))
						{ f=true;
							player[0]=1;
							player[1]=1;
						}
						else if((tic[2][0]==0)&&(tic[1][1]==0)&&(tic[0][2]==5))
						{f=true;
							player[0]=0;
							player[1]=2;
						}
						
				}
				
					
					return f;
		}
		static int win()
		{
			if(((tic[0][0]==1)&&(tic[0][1]==1)&&(tic[0][2]==1))||((tic[1][0]==1)&&(tic[1][1]==1)&&(tic[1][2]==1))||((tic[2][0]==1)&&(tic[2][1]==1)&&(tic[2][2]==1))||((tic[0][0]==1)&&(tic[1][0]==1)&&(tic[2][0]==1))||((tic[0][1]==1)&&(tic[1][1]==1)&&(tic[2][1]==1))||((tic[0][2]==1)&&(tic[1][2]==1)&&(tic[2][2]==1))||((tic[0][0]==1)&&(tic[1][1]==1)&&(tic[2][2]==1))||((tic[2][0]==1)&&(tic[1][1]==1)&&(tic[0][2]==1)))
				return 1;
			else
				return 0 ;

		}
		
		static int corner()
		{int f =0;
			if(tic[0][0]==5)
			{f=1;
				system[0]=0;
				system[1]=0;
			}
			else if(tic[0][2]==5)
			{f=2;
				system[0]=0;
				system[1]=2;
			}
			else if(tic[2][0]==5)
			{f=3;
				system[0]=2;
				system[1]=0;
			}
			else if(tic[2][2]==5)
			{	f=4;
				system[0]=2;
				system[1]=2;
			}
			return f;

		}
static void on(int x,int y,int play)
{
if(x==0 && y==0)
{
o1.setVisible(true);
b1.setVisible(false);
}
else if(x==0 && y==1)
{
o2.setVisible(true);
b2.setVisible(false);
}
else if(x==0 && y==2)
{
o3.setVisible(true);
b3.setVisible(false);
}
else if(x==1 && y==0)
{
o4.setVisible(true);
b4.setVisible(false);
}
else if(x==1 && y==1)
{
o5.setVisible(true);
b5.setVisible(false);
}
else if(x==1 && y==2)
{
o6.setVisible(true);
b6.setVisible(false);
}

else if(x==2 && y==0)
{
o7.setVisible(true);
b7.setVisible(false);
}
else if(x==2 && y==1)
{
o8.setVisible(true);
b8.setVisible(false);
}
else if(x==2 && y==2)
{
o9.setVisible(true);
b9.setVisible(false);
}
}
		}