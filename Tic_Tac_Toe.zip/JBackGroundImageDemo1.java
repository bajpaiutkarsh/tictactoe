//background image
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

import javax.swing.SwingUtilities;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import javax.swing.border.LineBorder;


public class JBackGroundImageDemo extends JFrame implements ActionListener
{
static int arr[]=new int[9];
static int player_level=0;
 Container con = null;
    JPanel panelBgImg;
	JFrame f1;
JButton l1,reset;
	int x=1;
	int x11=0;
	int playing=0;
	String str[]={"welcome.png","bg.jpg"};//"welcome1.png"};
     //String str;
	JButton b11,b12,b13,x1,x2,x3,x4,x5,x6,x7,x8,x9,o1,o2,o3,o4,o5,o6,o7,o8,o9,b1,b2,b3,b4,b5,b6,b7,b8,b9,p1,p2,computer;
    public JBackGroundImageDemo()
    {
			//x=x2;
		setTitle("SYSTEM APPLICATION");
        con = getContentPane();
        
        con.setLayout(null);
        ImageIcon imh = new ImageIcon(str[x11]);
        setSize(imh.getIconWidth(), imh.getIconHeight());
        
        panelBgImg = new JPanel()
        {
            public void paintComponent(Graphics g) 
            {
                Image img = new ImageIcon(str[x11]).getImage();
                Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));
                setPreferredSize(size);
                setMinimumSize(size);
                setMaximumSize(size);
                setSize(size);
                setLayout(null);
                g.drawImage(img, 0, 0, null);
            } 
        };
        
        con.add(panelBgImg);
        panelBgImg.setBounds(0, 0, imh.getIconWidth(), imh.getIconHeight());
        
        GridBagLayout layout = new GridBagLayout();
        
        JPanel panelContent = new JPanel(layout);
        GridBagConstraints gc = new GridBagConstraints();

        gc.insets = new Insets(3, 3, 3, 3);
        gc.gridx = 1;
        gc.gridy = 1;
		ImageIcon invalid = new ImageIcon("invalid.png");
		ImageIcon re = new ImageIcon("reset.png");
		 ImageIcon pi2 = new ImageIcon("p2.png");
		ImageIcon pi1 = new ImageIcon("p1.png");
        ImageIcon icon1 = new ImageIcon("conti.png");
		ImageIcon icon2 = new ImageIcon("ONE.png");
		ImageIcon icon3 = new ImageIcon("two.png");
		ImageIcon xi1 = new ImageIcon("x1.png");
		ImageIcon xi2 = new ImageIcon("x2.png");
		ImageIcon xi3 = new ImageIcon("x2.png");
		ImageIcon xi4 = new ImageIcon("x4.png");
		ImageIcon xi5 = new ImageIcon("x5.png");
		ImageIcon xi6 = new ImageIcon("x6.png");
		ImageIcon xi7 = new ImageIcon("x7.png");
		ImageIcon xi8 = new ImageIcon("x8.png");
		ImageIcon xi9 = new ImageIcon("x9.png");
//		ImageIcon bi1 = new ImageIcon("b1.png");
		ImageIcon bi1 = new ImageIcon("b1.png");
		ImageIcon bi2 = new ImageIcon("b2.png");
		ImageIcon bi3 = new ImageIcon("b3.png");
		ImageIcon bi4 = new ImageIcon("b4.png");
		ImageIcon bi5 = new ImageIcon("b5.png");
		ImageIcon bi6 = new ImageIcon("b6.png");
		ImageIcon bi7 = new ImageIcon("b7.png");
		ImageIcon bi8 = new ImageIcon("b8.png");
		ImageIcon bi9 = new ImageIcon("b9.png");
		ImageIcon oi1 = new ImageIcon("o1.png");
		ImageIcon oi2 = new ImageIcon("o2.png");
		ImageIcon oi3 = new ImageIcon("o3.png");
		ImageIcon oi4 = new ImageIcon("o4.png");
		ImageIcon oi5 = new ImageIcon("o5.png");
		ImageIcon oi6 = new ImageIcon("o6.png");
		ImageIcon oi7 = new ImageIcon("o7.png");
		ImageIcon oi8 = new ImageIcon("o8.png");
		ImageIcon oi9 = new ImageIcon("o9.png");
        b11 = new JButton("continue",icon1);
		b11.addActionListener(this);
		b12 = new JButton("One Player",icon2);
		b12.addActionListener(this);
		b13 = new JButton("Two Player",icon3);
		b13.addActionListener(this);
		 x1 = new JButton("continue",xi1);
		 x1.addActionListener(this);
		 x2 = new JButton("continue",xi2);
		 x2.addActionListener(this);
		 x3 = new JButton("continue",xi3);
		 x3.addActionListener(this);
		 x4 = new JButton("continue",xi4);
		 x4.addActionListener(this);
		 x5 = new JButton("continue",xi5);
		 x5.addActionListener(this);
		 x6 = new JButton("continue",xi6);
		 x6.addActionListener(this);
		 x7 = new JButton("continue",xi7);
		 x7.addActionListener(this);
		 x8 = new JButton("continue",xi8);
		 x8.addActionListener(this);
		 x9 = new JButton("continue",xi9);
		 x9.addActionListener(this);
		 
		 b1 = new JButton("continue",bi1);
		 b1.addActionListener(this);
		 b2 = new JButton("continue",bi2);
		 b2.addActionListener(this);
		 b3 = new JButton("continue",bi3);
		 b3.addActionListener(this);
		 b4 = new JButton("continue",bi4);
		 b4.addActionListener(this);
		 b5 = new JButton("continue",bi5);
		 b5.addActionListener(this);
		 b6 = new JButton("continue",bi6);
		 b6.addActionListener(this);
		 b7 = new JButton("continue",bi7);
		 b7.addActionListener(this);
		 b8 = new JButton("continue",bi8);
		 b8.addActionListener(this);
		 b9 = new JButton("continue",bi9);
		 b9.addActionListener(this);
		reset=new JButton("reset",re);
		reset.addActionListener(this);
		o1 = new JButton("continue",oi1);
		 o1.addActionListener(this);
		 o2 = new JButton("continue",oi2);
		 o2.addActionListener(this);
		 o3 = new JButton("continue",oi3);
		 o3.addActionListener(this);
		 o4 = new JButton("continue",oi4);
		 o4.addActionListener(this);
		 o5 = new JButton("continue",oi5);
		 o5.addActionListener(this);
		 o6 = new JButton("continue",oi6);
		 o6.addActionListener(this);
		 o7 = new JButton("continue",oi7);
		 o7.addActionListener(this);
		 o8 = new JButton("continue",oi8);
		 o8.addActionListener(this);
		 o9 = new JButton("continue",oi9);
		 o9.addActionListener(this);
		 p1 = new JButton("one",pi1);
		 p1.addActionListener(this);
		 p2 = new JButton("continue",pi2);
		 p2.addActionListener(this);
		 l1=new JButton("invalid move...",invalid);
		panelBgImg.setLayout(null);
		//panelBgImg.add(b1);
		panelBgImg.add(b12);
		panelBgImg.add(b13);
		panelBgImg.add(x1);
		panelBgImg.add(x2);
		panelBgImg.add(x3);
		panelBgImg.add(x4);
		panelBgImg.add(x5);
		panelBgImg.add(x6);
		panelBgImg.add(x7);
		panelBgImg.add(x8);
		panelBgImg.add(x9);
		panelBgImg.add(p1);
		panelBgImg.add(p2);
		panelBgImg.add(b1);
		panelBgImg.add(b2);
		panelBgImg.add(b3);
		panelBgImg.add(b4);
		panelBgImg.add(b5);
		panelBgImg.add(b6);
		panelBgImg.add(b7);
		panelBgImg.add(b8);
		panelBgImg.add(b9);
		panelBgImg.add(l1);
		panelBgImg.add(reset);
		panelBgImg.add(o1);
		panelBgImg.add(o2);
		panelBgImg.add(o3);
		panelBgImg.add(o4);
		panelBgImg.add(o5);
		panelBgImg.add(o6);
		panelBgImg.add(o7);
		panelBgImg.add(o8);
		panelBgImg.add(o9);
		//b1.setBounds(980,650,180,70);
		b12.setBounds(380,640,256,85);
		x1.setBounds(180,120,78,83);
		x2.setBounds(350,120,78,83);
		x3.setBounds(500,120,78,83);
		x4.setBounds(180,300,78,83);
		x5.setBounds(350,300,78,83);
		x6.setBounds(500,300,78,83);
		x7.setBounds(180,480,78,83);
		x8.setBounds(350,480,78,83);
		x9.setBounds(500,480,78,83);
		
		b1.setBounds(180,120,78,83);
		b2.setBounds(350,120,78,83);
		b3.setBounds(500,120,78,83);
		b4.setBounds(180,300,78,83);
		b5.setBounds(350,300,78,83);
		b6.setBounds(500,300,78,83);
		b7.setBounds(180,480,78,83);
		b8.setBounds(350,480,78,83);
		b9.setBounds(500,480,78,83);
		
		p1.setBounds(25,25,205,58);
		p2.setBounds(25,25,205,58);
		reset.setBounds(555,25,200,45);
		o1.setBounds(180,120,90,83);
		o2.setBounds(350,120,90,83);
		o3.setBounds(500,120,90,83);
		o4.setBounds(180,300,90,83);
		o5.setBounds(350,300,90,83);
		o6.setBounds(500,300,90,83);
		o7.setBounds(180,480,90,83);
		o8.setBounds(350,480,90,83);
		o9.setBounds(500,480,90,83);
		b13.setBounds(980,640,256,85);
		l1.setBounds(300,600,271,30);
		//b2.setVisible(false);
		//b3.setVisible(false);
		x1.setVisible(false);
		x2.setVisible(false);
		x3.setVisible(false);
		x4.setVisible(false);
		x5.setVisible(false);
		x6.setVisible(false);
		x7.setVisible(false);
		x8.setVisible(false);
		x9.setVisible(false);
		l1.setVisible(false);
		reset.setVisible(false);
		o1.setVisible(false);
		o2.setVisible(false);
		o3.setVisible(false);
		o4.setVisible(false);
		o5.setVisible(false);
		o6.setVisible(false);
		o7.setVisible(false);
		o8.setVisible(false);
		o9.setVisible(false);
        setResizable(false);
		
		b1.setVisible(false);
		b2.setVisible(false);
		b3.setVisible(false);
		b4.setVisible(false);
		b5.setVisible(false);
		b6.setVisible(false);
		b7.setVisible(false);
		b8.setVisible(false);
		b9.setVisible(false);
		
		p1.setVisible(false);
		p2.setVisible(false);
		//f1.setSize(320,320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public static void main(String[] args)throws IOException 
    {
		for(int i=0;i<9;i++)
		{
		arr[i]=5;
		}
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		//String str=br.readLine();
        new JBackGroundImageDemo().setVisible(true);
		
    }
	public void actionPerformed(ActionEvent ae)
	{
		
		if(ae.getSource()==b12)
		{
		player_level=1;
		try
		{
		ProcessBuilder pb=new ProcessBuilder("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe","web.html");
		Process start=pb.start();
		}
		catch(Exception e)
		{
		
		}  
		x11=(x11+1)%2;
		       ImageIcon imh = new ImageIcon(str[x11]);
        setSize(imh.getIconWidth(), imh.getIconHeight());
        
        panelBgImg = new JPanel()
        {
            public void paintComponent(Graphics g) 
            {
                Image img = new ImageIcon(str[x11]).getImage();
                Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));
                setPreferredSize(size);
                setMinimumSize(size);
                setMaximumSize(size);
                setSize(size);
                setLayout(null);
                g.drawImage(img, 0, 0, null);
            } 
        };
        
        con.add(panelBgImg);
        panelBgImg.setBounds(0, 0, imh.getIconWidth(), imh.getIconHeight());
        
        GridBagLayout layout = new GridBagLayout();
        
        JPanel panelContent = new JPanel(layout);
        GridBagConstraints gc = new GridBagConstraints();

        gc.insets = new Insets(3, 3, 3, 3);
        gc.gridx = 1;
        gc.gridy = 1;
		b12.setVisible(false);
		b13.setVisible(false);
		reset.setVisible(true);
	//	b3.setVisible(true);
	/*x1.setVisible(true);
		x2.setVisible(true);
		x3.setVisible(true);
		x4.setVisible(true);
		x5.setVisible(true);
		x6.setVisible(true);
		x7.setVisible(true);
		x8.setVisible(true);
		x9.setVisible(true);
		o1.setVisible(true);
		o2.setVisible(true);
		o3.setVisible(true);
		o4.setVisible(true);
		o5.setVisible(true);
		o6.setVisible(true);
		o7.setVisible(true);
		o8.setVisible(true);
		o9.setVisible(true);*/
		
		b1.setVisible(true);
		b2.setVisible(true);
		b3.setVisible(true);
		b4.setVisible(true);
		b5.setVisible(true);
		b6.setVisible(true);
		b7.setVisible(true);
		b8.setVisible(true);
		b9.setVisible(true);
		l1.setVisible(false);
		
		}
		
		if(ae.getSource()==b13)
		{
		player_level=2;
		try
		{
		JOptionPane.showMessageDialog(null,"welcome to concept4computer products\n                   THANKS");
		ProcessBuilder pb=new ProcessBuilder("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe","www.concept4computer.in");
		Process start=pb.start();
		}
		catch(Exception e)
		{
		
		}
		x11=(x11+1)%2;
		       ImageIcon imh = new ImageIcon(str[x11]);
        setSize(imh.getIconWidth(), imh.getIconHeight());
        
        panelBgImg = new JPanel()
        {
            public void paintComponent(Graphics g) 
            {
                Image img = new ImageIcon(str[x11]).getImage();
                Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));
                setPreferredSize(size);
                setMinimumSize(size);
                setMaximumSize(size);
                setSize(size);
                setLayout(null);
                g.drawImage(img, 0, 0, null);
            } 
        };
        
        con.add(panelBgImg);
        panelBgImg.setBounds(0, 0, imh.getIconWidth(), imh.getIconHeight());
        
        GridBagLayout layout = new GridBagLayout();
        
        JPanel panelContent = new JPanel(layout);
        GridBagConstraints gc = new GridBagConstraints();

        gc.insets = new Insets(3, 3, 3, 3);
        gc.gridx = 1;
        gc.gridy = 1;
		b12.setVisible(false);
	b13.setVisible(false);
	//	b3.setVisible(true);
/*	x1.setVisible(true);
		x2.setVisible(true);
		x3.setVisible(true);
		x4.setVisible(true);
		x5.setVisible(true);
		x6.setVisible(true);
		x7.setVisible(true);
		x8.setVisible(true);
		x9.setVisible(true);
		o1.setVisible(true);
		o2.setVisible(true);
		o3.setVisible(true);
		o4.setVisible(true);
		o5.setVisible(true);
		o6.setVisible(true);
		o7.setVisible(true);
		o8.setVisible(true);
		o9.setVisible(true);*/
		b1.setVisible(true);
		b2.setVisible(true);
		b3.setVisible(true);
		b4.setVisible(true);
		b5.setVisible(true);
		b6.setVisible(true);
		b7.setVisible(true);
		b8.setVisible(true);
		b9.setVisible(true);
		l1.setVisible(false);
		reset.setVisible(true);
		if(playing==0)
		{
		p1.setVisible(true);
		p2.setVisible(false);
		
		}
		else
		{
		p2.setVisible(true);
		p1.setVisible(false);
	
		}
		}
		if(ae.getSource()==reset)
		{
		playing=0;
		p1.setVisible(true);
		p2.setVisible(false);
		x1.setVisible(false);
		x2.setVisible(false);
		x3.setVisible(false);
		x4.setVisible(false);
		x5.setVisible(false);
		x6.setVisible(false);
		x7.setVisible(false);
		x8.setVisible(false);
		x9.setVisible(false);
		o1.setVisible(false);
		o2.setVisible(false);
		o3.setVisible(false);
		o4.setVisible(false);
		o5.setVisible(false);
		o6.setVisible(false);
		o7.setVisible(false);
		o8.setVisible(false);
		o9.setVisible(false);
		b1.setVisible(true);
		b2.setVisible(true);
		b3.setVisible(true);
		b4.setVisible(true);
		b5.setVisible(true);
		b6.setVisible(true);
		b7.setVisible(true);
		b8.setVisible(true);
		b9.setVisible(true);
		}
		if(ae.getSource()==b1)
		{  
l1.setVisible(false);			if(playing==0)
				{
					x1.setVisible(true);
					b1.setVisible(false);
					game(1,0);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
					
					
				}
				else
				{
					o1.setVisible(true);
					b1.setVisible(false);
					game(2,0);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
			if(ae.getSource()==b2)
		{  l1.setVisible(false);
			if(playing==0)
				{
					x2.setVisible(true);
					b2.setVisible(false);
					game(1,1);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o2.setVisible(true);
					b2.setVisible(false);
					game(2,1);
					playing=0;
if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
					}
				
		}
			if(ae.getSource()==b3)
		{  l1.setVisible(false);
			if(playing==0)
				{
					x3.setVisible(true);
					b3.setVisible(false);
                    game(1,2);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o3.setVisible(true);
					b3.setVisible(false);
					game(2,2);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
			if(ae.getSource()==b4)
		{  l1.setVisible(false);
			if(playing==0)
				{
					x4.setVisible(true);
					b4.setVisible(false);
					game(1,3);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o4.setVisible(true);
					b4.setVisible(false);
					game(2,3);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
			if(ae.getSource()==b5)
		{  l1.setVisible(false);
			if(playing==0)
				{
					x5.setVisible(true);
					b5.setVisible(false);
					game(1,4);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o5.setVisible(true);
					b5.setVisible(false);
					game(2,4);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
			if(ae.getSource()==b6)
		{  l1.setVisible(false);
			if(playing==0)
				{
					x6.setVisible(true);
					b6.setVisible(false);
					game(1,5);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o6.setVisible(true);
					b6.setVisible(false);
					game(2,5);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
		
		
			if(ae.getSource()==b7)
		{  l1.setVisible(false);
			if(playing==0)
				{
					x7.setVisible(true);
					b7.setVisible(false);
					game(1,6);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o7.setVisible(true);
					b7.setVisible(false);
					game(2,6);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
		if(ae.getSource()==b8)
		{  l1.setVisible(false);
			if(playing==0)
				{
					x8.setVisible(true);
					b8.setVisible(false);
					game(1,7);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o8.setVisible(true);
					b8.setVisible(false);
					game(2,7);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
		if(ae.getSource()==b9)
		{  l1.setVisible(false);
			if(playing==0)
				{
					x9.setVisible(true);
					b9.setVisible(false);
					game(1,8);
					playing=1;
					if(playing==1)
					{
						p2.setVisible(true);
						p1.setVisible(false);
					}
				}
				else
				{
					o9.setVisible(true);
					b9.setVisible(false);
					game(2,8);
					playing=0;
					if(playing==0)
					{
						p1.setVisible(true);
						p2.setVisible(false);
					}
				}
		}
		if(ae.getSource()==o1)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o2)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o3)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o4)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o5)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o6)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o7)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o8)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==o9)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x1)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x2)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x3)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x4)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x5)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x6)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x7)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x8)
	{
	l1.setVisible(true);
	}
	if(ae.getSource()==x9)
	{
	l1.setVisible(true);
	}
		
		
	}
	
static void game(int value,int place)
{
arr[place]=value;

if((arr[0]==1 && arr[1]==1 && arr[2]==1) ||(arr[0]==1 && arr[4]==1 && arr[8]==1)||(arr[3]==1 && arr[4]==1 && arr[5]==1)||(arr[6]==1 && arr[7]==1 && arr[8]==1) ||(arr[2]==1 && arr[4]==1 && arr[6]==1)||(arr[2]==1 && arr[5]==1 && arr[8]==1) ||(arr[0]==1 && arr[3]==1 && arr[6]==1) ||(arr[1]==1 && arr[4]==1 && arr[7]==1) )
{
try
{
String shutdownCmd = "player1won";
			Process child = Runtime.getRuntime().exec(shutdownCmd);
		System.exit(1);
		}
		catch(Exception e)
		{
		}
		}
		
		else if((arr[0]==2 && arr[1]==2 && arr[2]==2) ||(arr[0]==2 && arr[4]==2 && arr[8]==2)||(arr[3]==2 && arr[4]==2 && arr[5]==2)||(arr[6]==2 && arr[7]==2 && arr[8]==2) ||(arr[2]==2 && arr[4]==2 && arr[6]==2)||(arr[2]==2 && arr[5]==2 && arr[8]==2) ||(arr[0]==2 && arr[3]==2 && arr[6]==2) ||(arr[1]==2 && arr[4]==2 && arr[7]==2))
{
try
{
String shutdownCmd = "player2won";
			Process child = Runtime.getRuntime().exec(shutdownCmd);
		System.exit(2);
		}
		catch(Exception e)
		{
		}
		}
		else
		{
		 checkkd();
		}
}
static void checkkd()
{
int ch=0;
for(int i=0;i<9;i++)
{
if(arr[i]==5)
{
ch=5;
break;
}
}
if(ch!=5)
{
try
{
String shutdownCmd = "kd";
			Process child = Runtime.getRuntime().exec(shutdownCmd);
		System.exit(3);
		}
		catch(Exception e)
		{

}
		}
}
}	
	//	}
  
	