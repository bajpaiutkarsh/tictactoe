import java.util.*;
class tic
{
		static int tic[][];
		static int player[],system[],count;
		 
		public static int[] main()
		{	
			tic=new int[3][3];
			player=new int[2];
			system=new int[2];
		count=0;
			for(int m=0;m<3;m++)
			{
			for(int h=0;h<3;h++)
			{
				tic[m][h]=5;
			}
			}
		display();
			while(count<=9)
			{	if(count == 9)
				{
					System.out.printf("\n\n@@ !!! Khichadi pakk gyi !!! @@\n\n");
					break;
				}
				
				else
				{
				askmove();
				if(isvalid()==0)
				{
					System.out.printf("\n\n@@ !!! Invalid move !!! @@\n\n");
					askmove();
				}
				display();
				if(win()==1)
				{
					
					System.out.printf("\n@@ !!! Congratulations, you win !!! @@\n\n");
					break;
				}
				int m = findmove();
				
				if(m!=0)
				{	
					sysmove();
					display();
					if(m==5)
					{
						System.out.printf("\n\n @@ !!! Sorry, you loose !!! @@ \n\n");
							break;
					}
					
				}
				}
			}
		return system;
		}
		static void askmove()
		{	
			Scanner sc=new Scanner(System.in);
			System.out.printf("Enter the player position for '1' : ");
			//scanf("%d %d",&player[0],&player[1]);
			int a=sc.nextInt();
			int b=sc.nextInt();
			player[0]=a;
			player[1]=b;
		}
		static void sysmove()
		{
			System.out.printf("The system position for '0' is : ");
			System.out.printf(" %d %d ",system[0],system[1]);
		}
		static int isvalid()
		{
			if((player[0]>=0&&player[0]<=2)&&(player[1]>=0&&player[1]<=2)&&(tic[player[0]][player[1]] == 5))
			{
				tic[player[0]][player[1]] = 1 ;
				count++;
				return 1;
			}
			else
				return 0 ;
		}
		static int findmove()
{	int i,j,c=0,d=0,f=0,e=0,g=0;
				if(trywin(system[0],system[1]))
				{
					system[0]=player[0];
					system[1]=player[1];
					tic[system[0]][system[1]]=0;
					
					return 5;
					
				}
				
	
				if(checkwin(player[0],player[1]))
				{
					system[0]=player[0];
					system[1]=player[1];
					tic[system[0]][system[1]]=0;
					count++;
					return 1;
					
				}
				if(tic[1][1]==5)
				{
				system[0]=1;
					system[1]=1;
					tic[system[0]][system[1]]=0;
					count++;
					return 1;
				
				}
if((tic[1][1]==1))
{	
	if(tic[0][0]==5)
	{


					system[0]=0;
					system[1]=0;
					tic[system[0]][system[1]]=0;
					count++;
					return 1;}
	else if(tic[2][0]==5)
	{


					system[0]=2;
					system[1]=0;
					tic[system[0]][system[1]]=0;
					count++;
					return 1;}
	else if(tic[0][2]==5)
{


					system[0]=0;
					system[1]=2;
					tic[system[0]][system[1]]=0;
					count++;
					return 1;}	
else if(tic[2][2]==5)
{


					system[0]=2;
					system[1]=2;
					tic[system[0]][system[1]]=0;
					count++;
					return 1;}	


}	
			
				
		
	int cn =0;
	for(i=player[0]-1;i<=player[0]+1;i++)
	{
		for(j=player[1]-1;j<=player[1]+1;j++)
		{
			if((i>=0&&i<=2)&&(j>=0&&j<=2)&&(tic[i][j] == 5))
			{	
				if(player[0]==2&&player[1]==2)
				{
					f=2;
				}
				else
				{
					f=1;
				}
				if(cn==0)
				{cn++;
					c = i;
				d = j;	
				}
				
				if((i==0&&j==0)||(i==0&&j==2)||(i==2&&j==0)||(i==2&&j==2))
				{
					system[0]=i;
				system[1]=j;
				tic[i][j]=0;
				count++;
				return 1 ;
				}
			/*	if((player[0]==0&&player[1]==0)||(player[0]==0&&player[1]==2)||(player[0]==2&&player[1]==2)||(player[0]==2&&player[1]==2))
				{	
				if(corner())
					{
						tic[system[0]][system[1]]=0;
						count++;
						return 1;
					}
					
				}*/
				e=i;
				g=j;
			}
			
		}
	}
	if(f==1)
	{
	system[0]=c;
				system[1]=d;
				tic[c][d]=0;
				count++;
				return 1 ;
	}			
	else if(f==2)
	{system[0]=e;
				system[1]=g;
				tic[e][g]=0;
				count++;
				return 1 ;
	
	}
	for(i=0;i<=2;i++)
	{
		for(j=0;j<=2;j++)
		{
			if(tic[i][j]==5)
			{
				tic[i][j]=0;
				system[0]=i;
				system[1]=j;
				return 1;
			}
		}
	}
	return 0 ;
}
		static boolean checkwin(int a,int b)
		{	

		boolean f =false;	
				if((tic[a][0]==1)&&(tic[a][1]==1)&&(tic[a][2]==5))
				{	f=true;
					player[0]=a;
					player[1]=2;
				}
				else if((tic[a][0]==1)&&(tic[a][1]==5)&&(tic[a][2]==1))
				{	f=true;
					player[0]=a;
					player[1]=1;
				}
				else if((tic[a][0]==5)&&(tic[a][1]==1)&&(tic[a][2]==1))
				{	f=true;
					player[0]=a;
					player[1]=0;
				}
				else if((tic[0][b]==1)&&(tic[1][b]==1)&&(tic[2][b]==5))
				{	player[0]=2;
					player[1]=b;
					f=true;
				}
				else if((tic[0][b]==1)&&(tic[1][b]==5)&&(tic[2][b]==1))
				{	player[0]=1;
					player[1]=b;
					f=true;
				}
				else if((tic[0][b]==5)&&(tic[1][b]==1)&&(tic[2][b]==1))
				{	player[0]=0;
					player[1]=b;
					f=true;
				}
				else if((a==0&&b==0)||(b==2&&a==2)||(a==1&&b==1))
				{
						if((tic[0][0]==1)&&(tic[1][1]==1)&&(tic[2][2]==5))
						{f=true;
							player[0]=2;
							player[1]=2;
						}
						else if((tic[0][0]==1)&&(tic[2][2]==1)&&(tic[1][1]==5))
						{f=true;
							player[0]=1;
							player[1]=1;
						}
						else if((tic[2][2]==1)&&(tic[1][1]==1)&&(tic[0][0]==5))
						{f=true;
							player[0]=0;
							player[1]=0;
							
						}
				}
				else if((b==0&&a==2)||(a==0&&b==2)||(a==1&&b==1))
				{
						if((tic[0][2]==1)&&(tic[1][1]==1)&&(tic[2][0]==5))
						{f=true;
						player[0]=2;
							player[1]=0;
						}
						else if((tic[0][2]==1)&&(tic[2][0]==1)&&(tic[1][1]==5))
						{ f=true;
							player[0]=1;
							player[1]=1;
						}
						else if((tic[2][0]==1)&&(tic[1][1]==1)&&(tic[0][2]==5))
						{f=true;
							player[0]=0;
							player[1]=2;
						}
						
				}
				
					
					return f;
		}
		static boolean trywin(int a,int b)
		{	

		boolean f =false;	
				if((tic[a][0]==0)&&(tic[a][1]==0)&&(tic[a][2]==5))
				{	f=true;
					player[0]=a;
					player[1]=2;
				}
				else if((tic[a][0]==0)&&(tic[a][2]==0)&&(tic[a][1]==5))
				{	f=true;
					player[0]=a;
					player[1]=1;
				}
				else if((tic[a][2]==0)&&(tic[a][1]==0)&&(tic[a][0]==5))
				{	f=true;
					player[0]=a;
					player[1]=0;
				}
				else if((tic[0][b]==0)&&(tic[1][b]==0)&&(tic[2][b]==5))
				{	player[0]=2;
					player[1]=b;
					f=true;
				}
				else if((tic[0][b]==0)&&(tic[2][b]==0)&&(tic[1][b]==5))
				{	player[0]=1;
					player[1]=b;
					f=true;
				}
				else if((tic[2][b]==0)&&(tic[1][b]==0)&&(tic[0][b]==5))
				{	player[0]=0;
					player[1]=b;
					f=true;
				}
				else if((a==0&&b==0)||(b==2&&a==2)||(a==1&&b==1))
				{
						if((tic[0][0]==0)&&(tic[1][1]==0)&&(tic[2][2]==5))
						{f=true;
							player[0]=2;
							player[1]=2;
						}
						else if((tic[0][0]==0)&&(tic[2][2]==0)&&(tic[1][1]==5))
						{f=true;
							player[0]=1;
							player[1]=1;
						}
						else if((tic[2][2]==0)&&(tic[1][1]==0)&&(tic[0][0]==5))
						{f=true;
							player[0]=0;
							player[1]=0;
							
						}
				}
				else if((b==0&&a==2)||(a==0&&b==2)||(a==1&&b==1))
				{
						if((tic[0][2]==0)&&(tic[1][1]==0)&&(tic[2][0]==5))
						{f=true;
						player[0]=2;
							player[1]=0;
						}
						else if((tic[0][2]==0)&&(tic[2][0]==0)&&(tic[1][1]==5))
						{ f=true;
							player[0]=1;
							player[1]=1;
						}
						else if((tic[2][0]==0)&&(tic[1][1]==0)&&(tic[0][2]==5))
						{f=true;
							player[0]=0;
							player[1]=2;
						}
						
				}
				
					
					return f;
		}
		static int win()
		{
			if(((tic[0][0]==1)&&(tic[0][1]==1)&&(tic[0][2]==1))||((tic[1][0]==1)&&(tic[1][1]==1)&&(tic[1][2]==1))||((tic[2][0]==1)&&(tic[2][1]==1)&&(tic[2][2]==1))||((tic[0][0]==1)&&(tic[1][0]==1)&&(tic[2][0]==1))||((tic[0][1]==1)&&(tic[1][1]==1)&&(tic[2][1]==1))||((tic[0][2]==1)&&(tic[1][2]==1)&&(tic[2][2]==1))||((tic[0][0]==1)&&(tic[1][1]==1)&&(tic[2][2]==1))||((tic[2][0]==1)&&(tic[1][1]==1)&&(tic[0][2]==1)))
				return 1;
			//else	if(((tic[0][0]==0)&&(tic[0][1]==0)&&(tic[0][2]==0))||((tic[1][0]==0)&&(tic[1][1]==0)&&(tic[1][2]==0))||((tic[2][0]==0)&&(tic[2][1]==0)&&(tic[2][2]==0))||((tic[0][0]==0)&&(tic[1][0]==0)&&(tic[2][0]==0))||((tic[0][1]==0)&&(tic[1][1]==0)&&(tic[2][1]==0))||((tic[0][2]==0)&&(tic[1][2]==0)&&(tic[2][2]==0))||((tic[0][0]==0)&&(tic[1][1]==0)&&(tic[2][2]==0))||((tic[2][0]==0)&&(tic[1][1]==0)&&(tic[0][2]==0)))
				//return 2;
			else
				return 0 ;

		}
		/*static static void display()
		{
			int i,j;
		System.out.printf(" \n");
		for(i=0;i<=2;i++)
		{
			for(j=0;j<=2;j++)
			{
				System.out.printf(" %d ",tic[i][j]);
			}
			System.out.printf(" \n");
		}*/
	 static void display()
				  {

				 //clrscr();
		int i,j,k;

		 // System.out.printf("\n\t\t\tINSTRUCTIONS OF TIC TAC TOE\n");
		
		System.out.printf("\n\t\t\t  GAME OF TIC TAC TOE\n");
		 
		   int x=2;
		//   gotoxy(0,10);
		   System.out.printf("\n\n\n\n\n\n\n\n\n\n\n\n");
		  for(i=0;i<5;i++)
		  {
		  if(i==3)
		  {                       if(tic[0][0]==5)
			 System.out.printf("\t\t\t\t     *");
			 else
			 {     if(tic[0][0]==1)

			  System.out.printf("\t\t\t\t   X *");
			  else
			   System.out.printf("\t\t\t\t   %d *",tic[0][0]);

			  }
		   if(tic[0][1]==5)
		   {
		   System.out.printf("     *");

		   }

		   else
			{     if(tic[0][1]==1)

			  System.out.printf("   X *");
			  else
			   System.out.printf("   %d *",tic[0][1]);

			  }
		   if(tic[0][2]==5)
		   System.out.printf("     \n");

		   else
			 {     if(tic[0][2]==1)

			  System.out.printf("   X  \n");
			  else
			   System.out.printf("   %d  \n",tic[0][2]);

			  }

		   }  //rintf("\t\t\t\t     *     *     ");
		  System.out.printf("\t\t\t\t     *     *     ");
		  System.out.printf("\n");
		  x++;
		  }     //gotoxy(35,x);
		  System.out.printf("\t\t\t\t*****************\n");
		//  gotoxy(0,10);
		  for(j=0;j<5;j++)
		  {
			if(j==3)
		  {
		  // System.out.printf("\t\t\t\t   %d *  %d  *  %d \n",a[3],a[4],a[5]);
			if(tic[1][0]==5)
			 System.out.printf("\t\t\t\t     *");
			 else

			{     if(tic[1][0]==1)

			  System.out.printf("\t\t\t\t   X *");
			  else
			   System.out.printf("\t\t\t\t   %d *",tic[1][0]);

			  }
		   if(tic[1][1]==5)
		   {
		   System.out.printf("     *");

		   }
		   else
			  {     if(tic[1][1]==1)

			  System.out.printf("   X *");
			  else
			   System.out.printf("   %d *",tic[1][1]);

			  }
		   if(tic[1][2]==5)
		   System.out.printf("     \n");

		   else
			  {     if(tic[1][2]==1)

			  System.out.printf("   X  \n");
			  else
			   System.out.printf("   %d  \n",tic[1][2]);

			  }
		   }
		  System.out.printf("\t\t\t\t     *     *     ");
		  System.out.printf("\n");
		  x++;
		  }                   //  gotoxy(0,10);
					   System.out.printf("\t\t\t\t*****************\n");
			 for(k=0;k<5;k++)
		  {
		  if(k==3)
		  {
		 //  System.out.printf("\t\t\t\t   %d *  %d  *  %d \n",a[6],a[7],a[8]);
			if(tic[2][0]==5)
			 System.out.printf("\t\t\t\t     *");
			 else

			{     if(tic[2][0]==1)

			  System.out.printf("\t\t\t\t   X *");
			  else
			   System.out.printf("\t\t\t\t   %d *",tic[2][0]);

			  }
		   if(tic[2][1]==5)
		   {
		   System.out.printf("     *");

		   }
		   else
			  {     if(tic[2][1]==1)

			  System.out.printf("   X *");
			  else
			   System.out.printf("   %d *",tic[2][1]);

			  }
		   if(tic[2][2]==5)
		   System.out.printf("     \n");

		   else
			  {     if(tic[2][2]==1)

			  System.out.printf("   X  \n");
			  else
			   System.out.printf("   %d  \n",tic[2][2]);

			  }
		   }
		  System.out.printf("\t\t\t\t     *     *     ");
		  System.out.printf("\n");
		  }
		 //getch();
		  }/*
		System.out.printf(" \n");
		}*/
		static int corner()
		{int f =0;
			if(tic[0][0]==5)
			{f=1;
				system[0]=0;
				system[1]=0;
			}
			else if(tic[0][2]==5)
			{f=2;
				system[0]=0;
				system[1]=2;
			}
			else if(tic[2][0]==5)
			{f=3;
				system[0]=2;
				system[1]=0;
			}
			else if(tic[2][2]==5)
			{	f=4;
				system[0]=2;
				system[1]=2;
			}
			return f;

		}
}